<?php
$monster[1] = '<script>
var monsterMaxHP = 7;
var monsterActualHP = monsterMaxHP;
var monsterName = "Potwór #1";
</script>';

$monster[2] = '<script>
var monsterMaxHP = 10;
var monsterActualHP = monsterMaxHP;
var monsterName = "Potwór #2";
</script>';

$monster[3] = '<script>
var monsterMaxHP = 15;
var monsterActualHP = monsterMaxHP;
var monsterName = "Potwór #3";
</script>';